import React, { useState } from 'react';
import { X, Download, Copy, Check, FileCode, Archive } from 'lucide-react';

import indexHtmlRaw from '../../index.html?raw';
import packageJsonRaw from '../../package.json?raw';
import viteConfigRaw from '../../vite.config.ts?raw';
import tsconfigRaw from '../../tsconfig.json?raw';
import metadataRaw from '../../metadata.json?raw';
import firebaseConfigRaw from '../../firebase-applet-config.json?raw';
import firebaseBlueprintRaw from '../../firebase-blueprint.json?raw';
import firestoreRulesRaw from '../../firestore.rules?raw';
import mainTsxRaw from '../main.tsx?raw';
import firebaseTsRaw from '../firebase.ts?raw';
import appTsxRaw from '../App.tsx?raw';
import typesTsRaw from '../types.ts?raw';
import indexCssRaw from '../index.css?raw';
import initialDataRaw from '../data/initialData.ts?raw';
import homeVideosRaw from './HomeAndVideosPages.tsx?raw';
import proofsDiscoverReferRaw from './ProofsDiscoverReferPages.tsx?raw';
import profilePageRaw from './ProfilePage.tsx?raw';
import adminPageRaw from './AdminPage.tsx?raw';
import modalsRaw from './Modals.tsx?raw';
import floatingWidgetsRaw from './FloatingWidgets.tsx?raw';

interface CodeDownloadModalProps {
  isOpen: boolean;
  onClose: () => void;
}

interface SourceFileEntry {
  path: string;
  content: string;
}

const SOURCE_FILES: SourceFileEntry[] = [
  { path: 'index.html', content: indexHtmlRaw },
  { path: 'package.json', content: packageJsonRaw },
  { path: 'vite.config.ts', content: viteConfigRaw },
  { path: 'tsconfig.json', content: tsconfigRaw },
  { path: 'metadata.json', content: metadataRaw },
  { path: 'firebase-applet-config.json', content: firebaseConfigRaw },
  { path: 'firebase-blueprint.json', content: firebaseBlueprintRaw },
  { path: 'firestore.rules', content: firestoreRulesRaw },
  { path: 'src/main.tsx', content: mainTsxRaw },
  { path: 'src/firebase.ts', content: firebaseTsRaw },
  { path: 'src/App.tsx', content: appTsxRaw },
  { path: 'src/types.ts', content: typesTsRaw },
  { path: 'src/index.css', content: indexCssRaw },
  { path: 'src/data/initialData.ts', content: initialDataRaw },
  { path: 'src/components/HomeAndVideosPages.tsx', content: homeVideosRaw },
  { path: 'src/components/ProofsDiscoverReferPages.tsx', content: proofsDiscoverReferRaw },
  { path: 'src/components/ProfilePage.tsx', content: profilePageRaw },
  { path: 'src/components/AdminPage.tsx', content: adminPageRaw },
  { path: 'src/components/Modals.tsx', content: modalsRaw },
  { path: 'src/components/FloatingWidgets.tsx', content: floatingWidgetsRaw },
];

export const CodeDownloadModal: React.FC<CodeDownloadModalProps> = ({
  isOpen,
  onClose,
}) => {
  const [selectedFileIndex, setSelectedFileIndex] = useState(0);
  const [copiedFile, setCopiedFile] = useState(false);
  const [copiedAll, setCopiedAll] = useState(false);

  if (!isOpen) return null;

  const currentFile = SOURCE_FILES[selectedFileIndex];

  const handleCopyCurrent = () => {
    navigator.clipboard.writeText(currentFile.content);
    setCopiedFile(true);
    setTimeout(() => setCopiedFile(false), 2000);
  };

  const handleCopyAllCombined = () => {
    const combined = SOURCE_FILES.map(
      (f) => `/* ==========================================\n   FILE: ${f.path}\n   ========================================== */\n\n${f.content}`
    ).join('\n\n\n');
    navigator.clipboard.writeText(combined);
    setCopiedAll(true);
    setTimeout(() => setCopiedAll(false), 2500);
  };

  const handleDownloadCombinedTxt = () => {
    const combined = SOURCE_FILES.map(
      (f) => `/* ==========================================\n   FILE: ${f.path}\n   ========================================== */\n\n${f.content}`
    ).join('\n\n\n');
    const blob = new Blob([combined], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = 'sohoje-income-all-source-code.txt';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  const handleDownloadSingleFile = (file: SourceFileEntry) => {
    const blob = new Blob([file.content], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = file.path.replace(/\//g, '_');
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/75 backdrop-blur-sm flex items-center justify-center p-3 sm:p-6">
      <div className="bg-white border border-slate-200 rounded-2xl max-w-5xl w-full max-h-[90vh] flex flex-col overflow-hidden shadow-2xl">
        {/* Top Header */}
        <div className="px-6 py-4 bg-slate-900 text-white flex items-center justify-between shrink-0">
          <div>
            <h2 className="text-base sm:text-lg font-bold">
              সহজে ইনকাম — সম্পূর্ণ সোর্স কোড ডাউনলোড সেন্টার
            </h2>
            <p className="text-xs text-slate-300">
              এক ক্লিকে সম্পূর্ণ প্রজেক্ট (.ZIP) ডাউনলোড করুন অথবা যেকোনো ফাইলের কোড কপি ও ডাউনলোড করুন
            </p>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="w-8 h-8 rounded-lg hover:bg-slate-800 flex items-center justify-center text-slate-300 hover:text-white transition-colors cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Action Toolbar */}
        <div className="p-4 bg-slate-50 border-b border-slate-200 flex flex-wrap items-center justify-between gap-3 shrink-0">
          <div className="flex flex-wrap items-center gap-2.5">
            <a
              href="/sohoje-income-source-code.zip"
              download="sohoje-income-source-code.zip"
              className="px-4 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white text-xs sm:text-sm font-semibold rounded-xl flex items-center gap-2 transition-colors cursor-pointer"
            >
              <Archive className="w-4 h-4" />
              <span>সম্পূর্ণ প্রজেক্ট ডাউনলোড (.ZIP)</span>
            </a>

            <button
              type="button"
              onClick={handleDownloadCombinedTxt}
              className="px-4 py-2.5 bg-slate-900 hover:bg-slate-800 text-white text-xs sm:text-sm font-semibold rounded-xl flex items-center gap-2 transition-colors cursor-pointer"
            >
              <Download className="w-4 h-4" />
              <span>সব কোড এক ফাইলে ডাউনলোড (.TXT)</span>
            </button>
          </div>

          <button
            type="button"
            onClick={handleCopyAllCombined}
            className="px-3.5 py-2 bg-white hover:bg-slate-100 text-slate-800 border border-slate-200 text-xs font-semibold rounded-xl flex items-center gap-1.5 transition-colors cursor-pointer"
          >
            {copiedAll ? (
              <>
                <Check className="w-4 h-4 text-emerald-600" />
                <span>সবগুলো ফাইলের কোড কপি হয়েছে!</span>
              </>
            ) : (
              <>
                <Copy className="w-4 h-4" />
                <span>সবগুলো কোড একসাথে কপি করুন</span>
              </>
            )}
          </button>
        </div>

        {/* File Explorer + Code Viewer */}
        <div className="flex-1 grid grid-cols-1 md:grid-cols-12 min-h-0 overflow-hidden">
          {/* Left File List */}
          <div className="md:col-span-4 border-r border-slate-200 bg-slate-50/50 overflow-y-auto p-3 space-y-1">
            <div className="text-[11px] font-semibold text-slate-500 px-2 pb-1">
              প্রজেক্টের সকল ফাইলসমূহ ({SOURCE_FILES.length}টি)
            </div>
            {SOURCE_FILES.map((file, idx) => (
              <button
                key={file.path}
                type="button"
                onClick={() => setSelectedFileIndex(idx)}
                className={`w-full text-left px-3 py-2.5 rounded-xl text-xs font-mono-num flex items-center justify-between gap-2 transition-colors cursor-pointer ${
                  selectedFileIndex === idx
                    ? 'bg-slate-900 text-white font-semibold'
                    : 'text-slate-700 hover:bg-slate-200/70'
                }`}
              >
                <span className="flex items-center gap-2 truncate">
                  <FileCode className="w-3.5 h-3.5 shrink-0" />
                  <span className="truncate">{file.path}</span>
                </span>
              </button>
            ))}
          </div>

          {/* Right Code Content */}
          <div className="md:col-span-8 flex flex-col min-h-0 bg-slate-950 text-slate-100">
            <div className="px-4 py-2.5 bg-slate-900 border-b border-slate-800 flex items-center justify-between shrink-0">
              <span className="text-xs font-mono-num text-emerald-400">
                {currentFile.path}
              </span>
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={handleCopyCurrent}
                  className="px-3 py-1 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-lg text-xs font-medium flex items-center gap-1.5 cursor-pointer"
                >
                  {copiedFile ? (
                    <>
                      <Check className="w-3.5 h-3.5 text-emerald-400" />
                      <span>কপি হয়েছে</span>
                    </>
                  ) : (
                    <>
                      <Copy className="w-3.5 h-3.5" />
                      <span>এই ফাইল কপি করুন</span>
                    </>
                  )}
                </button>
                <button
                  type="button"
                  onClick={() => handleDownloadSingleFile(currentFile)}
                  className="px-3 py-1 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg text-xs font-medium flex items-center gap-1.5 cursor-pointer"
                >
                  <Download className="w-3.5 h-3.5" />
                  <span>ডাউনলোড</span>
                </button>
              </div>
            </div>

            <pre className="p-4 text-xs font-mono-num leading-relaxed overflow-auto flex-1 select-all">
              <code>{currentFile.content}</code>
            </pre>
          </div>
        </div>
      </div>
    </div>
  );
};
